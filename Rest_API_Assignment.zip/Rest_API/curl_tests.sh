#!/bin/bash

# SMS API Curl Test Script
# Tests all CRUD endpoints with Basic Authentication

BASE_URL="http://localhost:8000"
AUTH_HEADER="Authorization: Basic YWRtaW46cGFzc3dvcmQ="

echo "SMS API Curl Tests"
echo "=================="
echo

# Test 1: GET all transactions
echo "1. Testing GET /transactions (all transactions)"
echo "-----------------------------------------------"
curl -X GET "$BASE_URL/transactions" \
  -H "$AUTH_HEADER" \
  -H "Content-Type: application/json" | jq '.[0:3]' 2>/dev/null || echo "Response received (install jq for pretty formatting)"
echo
echo

# Test 2: GET specific transaction
echo "2. Testing GET /transactions/1 (specific transaction)"
echo "------------------------------------------------------"
curl -X GET "$BASE_URL/transactions/1" \
  -H "$AUTH_HEADER" \
  -H "Content-Type: application/json" | jq '.' 2>/dev/null || echo "Response received"
echo
echo

# Test 3: POST new transaction
echo "3. Testing POST /transactions (create new)"
echo "------------------------------------------"
curl -X POST "$BASE_URL/transactions" \
  -H "$AUTH_HEADER" \
  -H "Content-Type: application/json" \
  -d '{
    "sender": "Curl Test User",
    "recipient": "API Tester",
    "message": "This is a curl test message",
    "timestamp": "2024-01-16 12:00:00",
    "amount": 0.00,
    "status": "sent"
  }' | jq '.' 2>/dev/null || echo "Response received"
echo
echo

# Test 4: PUT update transaction (assuming transaction 1 exists)
echo "4. Testing PUT /transactions/1 (update existing)"
echo "------------------------------------------------"
curl -X PUT "$BASE_URL/transactions/1" \
  -H "$AUTH_HEADER" \
  -H "Content-Type: application/json" \
  -d '{
    "sender": "Updated via Curl",
    "recipient": "Jane Smith",
    "message": "This message was updated via curl",
    "timestamp": "2024-01-15 10:30:00",
    "amount": 0.00,
    "status": "delivered"
  }' | jq '.' 2>/dev/null || echo "Response received"
echo
echo

# Test 5: DELETE transaction (assuming transaction 1 exists)
echo "5. Testing DELETE /transactions/1 (delete)"
echo "------------------------------------------"
curl -X DELETE "$BASE_URL/transactions/1" \
  -H "$AUTH_HEADER" \
  -H "Content-Type: application/json" | jq '.' 2>/dev/null || echo "Response received"
echo
echo

# Test 6: Unauthorized access
echo "6. Testing unauthorized access (should return 401)"
echo "--------------------------------------------------"
curl -X GET "$BASE_URL/transactions" \
  -H "Content-Type: application/json" | jq '.' 2>/dev/null || echo "Response received"
echo
echo

echo "All tests completed!"
echo "===================="
echo
echo "Note: Install 'jq' for pretty JSON formatting:"
echo "  Windows: choco install jq"
echo "  macOS: brew install jq"
echo "  Linux: apt-get install jq"
