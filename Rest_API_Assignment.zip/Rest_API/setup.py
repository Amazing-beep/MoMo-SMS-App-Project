"""
Setup script for SMS REST API project
Initializes the project by parsing XML data
"""

import os
import sys
import subprocess


def run_xml_parser():
    """Run the XML parser to create JSON data"""
    print("Setting up SMS REST API project...")
    print("=" * 40)
    
    # Check if XML file exists
    if not os.path.exists("modified_sms_v2.xml"):
        print("Error: modified_sms_v2.xml not found!")
        print("Make sure you're running this from the project root directory.")
        return False
    
    # Navigate to dsa folder and run parser
    try:
        print("1. Parsing XML data...")
        os.chdir("dsa")
        result = subprocess.run([sys.executable, "xml_parser.py"], 
                             capture_output=True, text=True)
        
        if result.returncode == 0:
            print("   ✓ XML parsing completed successfully")
            print("   ✓ Created sms_data.json")
        else:
            print(f"   ✗ Error parsing XML: {result.stderr}")
            return False
        
        # Go back to parent directory
        os.chdir("..")
        
        # Check if JSON file was created
        if os.path.exists("dsa/sms_data.json"):
            print("2. Data setup completed!")
            return True
        else:
            print("   ✗ sms_data.json not found after parsing")
            return False
            
    except Exception as e:
        print(f"   ✗ Exception during setup: {e}")
        return False


def run_dsa_analysis():
    """Run DSA performance analysis"""
    try:
        print("\n3. Running DSA performance analysis...")
        os.chdir("dsa")
        result = subprocess.run([sys.executable, "search_algorithms.py"], 
                             capture_output=True, text=True)
        
        if result.returncode == 0:
            print("   ✓ DSA analysis completed")
            print("   Check the output above for performance results")
        else:
            print(f"   ✗ Error in DSA analysis: {result.stderr}")
        
        os.chdir("..")
        
    except Exception as e:
        print(f"   ✗ Exception during DSA analysis: {e}")


def show_next_steps():
    """Show next steps for the user"""
    print("\n" + "=" * 40)
    print("Setup completed! Next steps:")
    print("=" * 40)
    print("1. Start the API server:")
    print("   cd api")
    print("   python sms_api.py")
    print()
    print("2. Test the API (in a new terminal):")
    print("   python test_api.py")
    print()
    print("3. Or test manually with curl:")
    print("   curl -X GET http://localhost:8000/transactions \\")
    print("     -H \"Authorization: Basic YWRtaW46cGFzc3dvcmQ=\"")
    print()
    print("4. View API documentation:")
    print("   docs/api_docs.md")
    print()
    print("Authentication:")
    print("   Username: admin")
    print("   Password: password")


if __name__ == "__main__":
    print("SMS REST API Project Setup")
    print("=" * 30)
    
    # Run XML parser
    if run_xml_parser():
        # Run DSA analysis
        run_dsa_analysis()
        
        # Show next steps
        show_next_steps()
    else:
        print("\nSetup failed. Please check the error messages above.")
        sys.exit(1)
