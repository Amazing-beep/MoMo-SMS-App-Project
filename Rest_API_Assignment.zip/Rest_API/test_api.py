"""
API Testing Script
Tests all CRUD endpoints with proper authentication
"""

import requests
import json
import base64
from typing import Dict, Any


class APITester:
    """Test class for SMS API endpoints"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.auth_header = self._create_auth_header()
    
    def _create_auth_header(self) -> Dict[str, str]:
        """Create Basic Authentication header"""
        credentials = base64.b64encode(b"admin:password").decode('utf-8')
        return {"Authorization": f"Basic {credentials}"}
    
    def test_get_all_transactions(self) -> bool:
        """Test GET /transactions endpoint"""
        try:
            response = requests.get(f"{self.base_url}/transactions", headers=self.auth_header)
            print(f"GET /transactions - Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"  Found {len(data)} transactions")
                return True
            else:
                print(f"  Error: {response.text}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def test_get_specific_transaction(self, transaction_id: int) -> bool:
        """Test GET /transactions/{id} endpoint"""
        try:
            response = requests.get(f"{self.base_url}/transactions/{transaction_id}", headers=self.auth_header)
            print(f"GET /transactions/{transaction_id} - Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"  Transaction: {data['sender']} -> {data['recipient']}")
                return True
            else:
                print(f"  Error: {response.text}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def test_create_transaction(self) -> bool:
        """Test POST /transactions endpoint"""
        new_transaction = {
            "sender": "Test User",
            "recipient": "API Tester",
            "message": "This is a test message",
            "timestamp": "2024-01-16 12:00:00",
            "amount": 0.00,
            "status": "sent"
        }
        
        try:
            headers = {**self.auth_header, "Content-Type": "application/json"}
            response = requests.post(f"{self.base_url}/transactions", 
                                   headers=headers, 
                                   json=new_transaction)
            print(f"POST /transactions - Status: {response.status_code}")
            
            if response.status_code == 201:
                data = response.json()
                print(f"  Created transaction ID: {data['id']}")
                return data['id']  # Return ID for further testing
            else:
                print(f"  Error: {response.text}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def test_update_transaction(self, transaction_id: int) -> bool:
        """Test PUT /transactions/{id} endpoint"""
        updated_transaction = {
            "sender": "Updated Sender",
            "recipient": "Updated Recipient",
            "message": "This message has been updated",
            "timestamp": "2024-01-16 12:30:00",
            "amount": 5.50,
            "status": "delivered"
        }
        
        try:
            headers = {**self.auth_header, "Content-Type": "application/json"}
            response = requests.put(f"{self.base_url}/transactions/{transaction_id}",
                                  headers=headers,
                                  json=updated_transaction)
            print(f"PUT /transactions/{transaction_id} - Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"  Updated: {data['sender']} -> {data['recipient']}")
                return True
            else:
                print(f"  Error: {response.text}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def test_delete_transaction(self, transaction_id: int) -> bool:
        """Test DELETE /transactions/{id} endpoint"""
        try:
            response = requests.delete(f"{self.base_url}/transactions/{transaction_id}", 
                                    headers=self.auth_header)
            print(f"DELETE /transactions/{transaction_id} - Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"  Deleted: {data['deleted']['sender']} -> {data['deleted']['recipient']}")
                return True
            else:
                print(f"  Error: {response.text}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def test_unauthorized_access(self) -> bool:
        """Test unauthorized access (should return 401)"""
        try:
            response = requests.get(f"{self.base_url}/transactions")
            print(f"GET /transactions (no auth) - Status: {response.status_code}")
            
            if response.status_code == 401:
                print("  ✓ Correctly rejected unauthorized access")
                return True
            else:
                print(f"  ✗ Expected 401, got {response.status_code}")
                return False
        except Exception as e:
            print(f"  Exception: {e}")
            return False
    
    def run_all_tests(self):
        """Run complete test suite"""
        print("SMS API Test Suite")
        print("=" * 30)
        
        # Test unauthorized access first
        print("\n1. Testing Unauthorized Access:")
        self.test_unauthorized_access()
        
        # Test GET operations
        print("\n2. Testing GET Operations:")
        self.test_get_all_transactions()
        self.test_get_specific_transaction(1)
        
        # Test POST operation
        print("\n3. Testing POST Operation:")
        new_id = self.test_create_transaction()
        
        if new_id:
            # Test PUT operation
            print("\n4. Testing PUT Operation:")
            self.test_update_transaction(new_id)
            
            # Test DELETE operation
            print("\n5. Testing DELETE Operation:")
            self.test_delete_transaction(new_id)
        
        print("\nTest suite completed!")


if __name__ == "__main__":
    tester = APITester()
    tester.run_all_tests()
