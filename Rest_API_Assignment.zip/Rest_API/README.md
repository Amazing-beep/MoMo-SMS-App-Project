# SMS Transactions REST API

A beginner-level REST API implementation for managing SMS transaction data, built with Python's built-in `http.server` module.

## Project Structure

```
Rest_API/
├── api/                    # REST API implementation
│   └── sms_api.py         # Main API server
├── dsa/                   # Data Structures & Algorithms
│   ├── xml_parser.py      # XML parsing and JSON conversion
│   └── search_algorithms.py # Linear search vs Dictionary lookup
├── docs/                  # Documentation
│   └── api_docs.md        # API documentation
├── screenshots/           # Test screenshots
├── modified_sms_v2.xml    # Sample XML data
└── README.md              # This file
```

## Features

- **CRUD Operations**: Create, Read, Update, Delete SMS transactions
- **Basic Authentication**: Username/password protection
- **XML Parsing**: Convert XML data to JSON format
- **DSA Implementation**: Linear search vs Dictionary lookup comparison
- **RESTful Design**: Standard HTTP methods and status codes

## Prerequisites

- Python 3.6 or higher
- No external dependencies required (uses only built-in libraries)

## Setup Instructions

### 1. Clone or Download the Project
```bash
# If using git
git clone <repository-url>
cd Rest_API

# Or simply download and extract the project files
```

### 2. Parse XML Data (First Time Setup)
```bash
# Navigate to dsa folder
cd dsa

# Run XML parser to convert XML to JSON
python xml_parser.py

# This creates sms_data.json with parsed transaction data
```

### 3. Run DSA Performance Analysis (Optional)
```bash
# Still in dsa folder
python search_algorithms.py

# This will show performance comparison between search methods
```

### 4. Start the API Server
```bash
# Navigate to api folder
cd ../api

# Start the REST API server
python sms_api.py

# Server will start on http://localhost:8000
```

### 5. Test the API
Open a new terminal and test the endpoints:

```bash
# Test GET all transactions (with authentication)
curl -X GET http://localhost:8000/transactions \
  -H "Authorization: Basic YWRtaW46cGFzc3dvcmQ="

# Test GET specific transaction
curl -X GET http://localhost:8000/transactions/1 \
  -H "Authorization: Basic YWRtaW46cGFzc3dvcmQ="
```

## Authentication

**Username:** `admin`  
**Password:** `password`

The API uses Basic Authentication. Include the Authorization header in all requests:
```
Authorization: Basic YWRtaW46cGFzc3dvcmQ=
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/transactions` | List all transactions |
| GET | `/transactions/{id}` | Get specific transaction |
| POST | `/transactions` | Create new transaction |
| PUT | `/transactions/{id}` | Update transaction |
| DELETE | `/transactions/{id}` | Delete transaction |

For detailed API documentation, see [docs/api_docs.md](docs/api_docs.md)

## Testing Examples

### Using curl
```bash
# Create new transaction
curl -X POST http://localhost:8000/transactions \
  -H "Authorization: Basic YWRtaW46cGFzc3dvcmQ=" \
  -H "Content-Type: application/json" \
  -d '{
    "sender": "Test User",
    "recipient": "Another User", 
    "message": "Hello World",
    "timestamp": "2024-01-16 12:00:00",
    "amount": 0.00,
    "status": "sent"
  }'

# Update transaction
curl -X PUT http://localhost:8000/transactions/1 \
  -H "Authorization: Basic YWRtaW46cGFzc3dvcmQ=" \
  -H "Content-Type: application/json" \
  -d '{
    "sender": "Updated Sender",
    "recipient": "Jane Smith",
    "message": "Updated message",
    "timestamp": "2024-01-15 10:30:00", 
    "amount": 0.00,
    "status": "delivered"
  }'

# Delete transaction
curl -X DELETE http://localhost:8000/transactions/1 \
  -H "Authorization: Basic YWRtaW46cGFzc3dvcmQ="
```

### Using Postman
1. Import the collection or manually create requests
2. Set Base URL: `http://localhost:8000`
3. Add Basic Auth: Username `admin`, Password `password`
4. Set Content-Type: `application/json` for POST/PUT requests

## Data Structures & Algorithms

The project includes performance analysis comparing:

- **Linear Search**: O(n) time complexity
- **Dictionary Lookup**: O(1) time complexity

Run `python dsa/search_algorithms.py` to see the performance comparison results.

## Security Considerations

**Basic Authentication Limitations:**
- Credentials sent in every request (base64 encoded)
- No encryption or session management
- Vulnerable to replay attacks
- Credentials easily decoded

**Recommended Alternatives:**
- JWT (JSON Web Tokens)
- OAuth2
- API Keys
- Session-based authentication

## Troubleshooting

### Common Issues

1. **"sms_data.json not found"**
   - Run `python xml_parser.py` in the dsa folder first

2. **"Connection refused"**
   - Make sure the API server is running on port 8000
   - Check if another application is using port 8000

3. **"401 Unauthorized"**
   - Verify authentication credentials: username `admin`, password `password`
   - Check Authorization header format

4. **"Module not found" errors**
   - Ensure you're running scripts from the correct directory
   - Check Python path and file structure

### Port Configuration
To change the server port, modify the `run_server()` function in `api/sms_api.py`:
```python
def run_server(port: int = 8000):  # Change 8000 to desired port
```

## Project Requirements Met

✅ **Data Parsing**: XML to JSON conversion  
✅ **API Implementation**: Full CRUD REST API  
✅ **Authentication**: Basic Auth implementation  
✅ **API Documentation**: Complete endpoint documentation  
✅ **DSA Integration**: Linear search vs Dictionary lookup  
✅ **Testing**: curl examples and validation  

## File Size Compliance
All code files are kept under 90 lines as required:
- `xml_parser.py`: ~85 lines
- `search_algorithms.py`: ~88 lines  
- `sms_api.py`: ~89 lines

## License
This project is created for educational purposes as a beginner-level REST API assignment.
